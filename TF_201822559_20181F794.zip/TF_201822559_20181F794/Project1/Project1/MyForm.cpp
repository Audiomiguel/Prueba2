#include "MyForm.h"

using namespace Project1;
[System::STAThreadAttribute]
int main() {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Application::Run(gcnew MyForm());
//	Project1::MyForm form;
	return 0;
}